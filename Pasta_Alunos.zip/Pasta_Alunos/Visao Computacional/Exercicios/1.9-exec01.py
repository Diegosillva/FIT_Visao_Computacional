# 1.Faça um Programa que leia um vetor de 10 números reais e mostre-os na ordem inversa.

lista = list(range(10, 101, 10))
lista.reverse()
print(lista)
