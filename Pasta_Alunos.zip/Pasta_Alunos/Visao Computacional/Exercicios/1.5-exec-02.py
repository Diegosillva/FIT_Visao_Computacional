# 2.Faça um programa que peça o raio de um círculo e calcule sua área.
import math

raio = float(input("Digite o valor do Raio: "))
area = math.pi * raio * raio
print(f"Area do circulo e: {area:.1f}")
