# 1.Faça um programa que peça as 4 notas de um aluno e mostre a média final.
n1 = float(input("Primeira nota: "))
n2 = float(input("Segunda nota: "))
n3 = float(input("Terceira nota: "))
n4 = float(input("Quarta nota: "))

media = (n1 + n2 + n3 + n4) / 4

print(f"Sua media foi: {media} ")
