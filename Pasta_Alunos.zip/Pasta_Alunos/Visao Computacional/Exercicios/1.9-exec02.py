"""2.Faça um programa que utilize a lista a seguir. Para cada número na lista, mostre seu valor em dobro.

números = [3, 2, 1, 0, -1, 2, 3]"""

numeros = [3, 2, 1, 0, -1, 2, 3]
for numero in numeros:
    dobro = numero * 2
    print(dobro)
